There are our wireframes that we used:
https://www.figma.com/file/DjKTY4a9rohVnJYTaowhFI/Tracking-Rent-Car-Dashboard-(Community)?node-id=0%3A1